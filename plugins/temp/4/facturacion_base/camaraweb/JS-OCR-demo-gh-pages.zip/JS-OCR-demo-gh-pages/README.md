JS-OCR-demo
===========

JavaScript optical character recognition demo. Check it out [here](https://kdzwinel.github.io/JS-OCR-demo/).
