<?php
define('FS_DB_TYPE', 'MYSQL');
define('FS_DB_HOST', 'localhost');
define('FS_DB_PORT', '3306');
define('FS_DB_NAME', 'intersecom');
define('FS_DB_USER', 'root');
define('FS_DB_PASS', '');
define('FS_CACHE_HOST', '');
define('FS_CACHE_PORT', '11211');
define('FS_CACHE_PREFIX', 'H8lnvxbB_');
define('FS_TMP_NAME', 'Q4EbzMa1Ct50psO9mkuL/');
define('FS_COOKIES_EXPIRE', 604800);
define('FS_ITEM_LIMIT', 50);
define('FS_DB_HISTORY', FALSE);
define('FS_DEMO', FALSE);
define('FS_DISABLE_MOD_PLUGINS', FALSE);
define('FS_DISABLE_ADD_PLUGINS', FALSE);
define('FS_DISABLE_RM_PLUGINS', FALSE);
